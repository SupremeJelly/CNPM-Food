package com.vanhuy.order_service.constant;

import java.math.BigDecimal;

public class Constants {
    public static final BigDecimal TAX_RATE = BigDecimal.valueOf(0.08);
}
