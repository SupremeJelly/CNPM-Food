package com.vanhuy.restaurant_service.dto;

public record RestaurantDTO
        (Integer restaurantId, String name, String address, String image) {
}
