package com.vanhuy.restaurant_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("test")
@SpringBootTest
class RestaurantServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
